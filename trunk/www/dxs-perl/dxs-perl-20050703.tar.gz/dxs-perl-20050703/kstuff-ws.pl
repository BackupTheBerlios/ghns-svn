#!/usr/bin/perl
#
# Web service handler for multiple backend services
# Copyright (C) 2005 Josef Spillner <josef@kstuff.org>
# Published under GNU GPL conditions

use strict;
use SOAP::Transport::HTTP;

SOAP::Transport::HTTP::CGI
	-> dispatch_to("GHNS")
	-> handle;

