#!/usr/bin/perl
#
# Backend module for the kstuff web service handler: Get Hot New Stuff
# Copyright (C) 2005 Josef Spillner <josef@kstuff.org>
# Published under GNU GPL conditions

package GHNS;

use strict;
use Data::Dumper;
use MIME::Base64;
use SOAP::Lite;

use vars qw(@ISA);

my $version = "0.2";

@ISA = qw(Exporter SOAP::Server::Parameters);

my $uploaddir = "/tmp/uploads";

sub GHNSUpload{
	my($self, @args) = @_;
	my $envelope = pop @args;

	my $author = $envelope->valueof("//GHNSUpload/author");
	my $version = $envelope->valueof("//GHNSUpload/version");
	my $release = $envelope->valueof("//GHNSUpload/release");
	my $license = $envelope->valueof("//GHNSUpload/license");
	my $name = $envelope->valueof("//GHNSUpload/name");
	my $type = $envelope->valueof("//GHNSUpload/type");
	my $summary = $envelope->valueof("//GHNSUpload/summary");
	my $payload = $envelope->valueof("//GHNSUpload/payload");
	my $preview = $envelope->valueof("//GHNSUpload/preview");

	my $ret = "failure";

	if(($author) and ($version) and ($release) and ($license) and ($name) and ($type)){
		if(($summary) and ($payload) and ($preview)){
			mkdir $uploaddir, 0777;
			open(FILE, ">$uploaddir/tmp.preview.png");
			print FILE MIME::Base64::decode_base64($preview);
			close(FILE);
			open(FILE, ">$uploaddir/tmp.payload.png");
			print FILE MIME::Base64::decode_base64($payload);
			close(FILE);
			open(FILE, ">$uploaddir/tmp.meta");
			print FILE "<?xml version='1.0'?>\n";
			print FILE "<knewstuff>\n";
			print FILE "<stuff type='$type'>\n";
			print FILE "<author email=''>$author</author>\n";
			print FILE "<version>$version</version>\n";
			print FILE "<release>$release</release>\n";
			print FILE "<licence>$license</licence>\n";
			print FILE "<name>$name</name>\n";
			print FILE "<summary>$summary</summary>\n";
			print FILE "<preview>tmp.preview.png</preview>\n";
			print FILE "<payload>tmp.payload.png</payload>\n";
			print FILE "</stuff>\n";
			print FILE "</knewstuff>\n";
			print FILE "\n";
			close(FILE);

			$ret = "success";
		}
	}

	return $ret;
}

sub GHNSInfo{
	my $server = SOAP::Data->name("server" => "Desktop Exchange Service (DXS)");
	my $version = SOAP::Data->name("version" => "$version");
	my $provider = SOAP::Data->name("provider" => "KStuff Development Server");
	my $url = SOAP::Data->name("url" => "http://kstuff.org/");
	return [$server, $version, $provider, $url];
}

1;
