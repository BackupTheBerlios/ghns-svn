#!/usr/bin/perl
#
# Web service invocation client
# Copyright (C) 2005 Josef Spillner <josef@kstuff.org>
# Published under GNU GPL conditions

package wsclient;

use strict;
use Getopt::Long qw(:config no_auto_abbrev bundling no_ignore_case);
use XML::DOM;
use MIME::Base64;
use SOAP::Lite +trace => "debug";
use Term::Shell;
use Data::Dumper;
use base qw(Term::Shell);

my $version = "0.2";

my $default_webservice = "http://localhost/cgi-bin/kstuff-ws.pl";

my ($opt_upload, $opt_provider, $opt_help, $opt_version, $opt_webservice, $opt_information);

$opt_webservice = $default_webservice;

my $options = GetOptions(
	"h|help"         => \$opt_help,
	"v|version"      => \$opt_version,
	"u|upload=s"     => \$opt_upload,
	"p|provider=s"   => \$opt_provider,
	"w|webservice=s" => \$opt_webservice,
	"i|information"  => \$opt_information
);
if(!$options){
	exit 1;
}

if($opt_help){
	print "wsclient - command line client to the Desktop Exchange Service (DXS)\n";
	print "Copyright (C) 2005 Josef Spillner <josef\@kstuff.org>\n";
	print "Published under GNU GPL conditions\n";
	print;
	print "Operations:\n";
	print "[-u | --upload <file>   ] Upload .meta file and associated contents\n";
	print "[-i | --information     ] Display provider information\n";
	print;
	print "Options:\n";
	#print "[-p | --provider <url>  ] Select a provider URL (if not given, use default: kstuff.org)\n";
	print "[-w | --webservice <url>] Select a webservice URL (if not given, use default: $default_webservice)\n";
	print "[-v | --version         ] Print version information\n";
	exit;
}
if($opt_version){
	print "$version\n";
	exit;
}

if($opt_information){
	information($opt_webservice);
	exit;
}
if($opt_upload){
	upload($opt_upload, $opt_webservice);
	exit;
}

interactive();

sub upload{
	my $arg_file = shift(@_);
	my $arg_webservice = shift(@_);

	my ($author, $version, $release, $license, $name, $type, $summary, $payload, $preview);
	my $error = 0;
	my %meta;

	print "Preparing web service invocation.\n";

	my $parser = new XML::DOM::Parser;
	my $doc = $parser->parsefile($arg_file);

	my $knewstuff = $doc->getDocumentElement();
	for my $stuff($knewstuff->getElementsByTagName("stuff")){
		$type = $stuff->getAttribute("type");
		my @taglist = $stuff->getElementsByTagName("*");
		for my $tag(@taglist){
			my $tagname = $tag->getTagName;
			my $tagvalue = "";
			if($tag->getFirstChild){
				$tagvalue = $tag->getFirstChild->getData;
			}
	
			if($tagname eq "author"){
				$author = $tagvalue;
			}elsif($tagname eq "version"){
				$version = $tagvalue;
			}elsif($tagname eq "release"){
				$release = $tagvalue;
			}elsif($tagname eq "licence"){
				$license = $tagvalue;
			}elsif($tagname eq "name"){
				$name = $tagvalue;
			}elsif($tagname eq "type"){
				$type = $tagvalue;
			}elsif($tagname eq "summary"){
				$summary = $tagvalue;
			}elsif($tagname eq "payload"){
				$payload = $tagvalue;
			}elsif($tagname eq "preview"){
				$preview = $tagvalue;
			}
		}
	}

	local($/) = undef;

	open(FILE, $preview);
	my $preview_data = MIME::Base64::encode_base64(<FILE>);
	close(FILE);
	open(FILE, $payload);
	my $payload_data = MIME::Base64::encode_base64(<FILE>);
	close(FILE);

	$author = SOAP::Data->name("author" => $author);
	$version = SOAP::Data->name("version" => $version);
	$release = SOAP::Data->name("release" => $release);
	$license = SOAP::Data->name("license" => $license);
	$name = SOAP::Data->name("name" => $name);
	$type = SOAP::Data->name("type" => $type);
	$summary = SOAP::Data->name("summary" => $summary);
	$payload = SOAP::Data->name("payload" => $payload_data);
	$preview = SOAP::Data->name("preview" => $preview_data);

	if(!$error){
		my $ns = "urn:GHNS";

		my $ws = SOAP::Lite
			#-> service("file:./ghns.wsdl")
			-> readable(1)
			-> uri($ns)
			-> proxy($arg_webservice);

		my $som = $ws->GHNSUpload($author, $version, $release, $license, $name, $type, $summary,
			$payload, $preview);

		if($som->fault){
			my $string = $som->faultstring;
			chomp $string;
			print "Error: $string\n";
		}else{
			print "The response was:\n";
			print $som->result, "\n";
		}
	}
}

sub information{
	my $arg_webservice = shift(@_);

	my $ns = "urn:GHNS";

	my $ws = SOAP::Lite
		-> readable(1)
		-> uri($ns)
		-> proxy($arg_webservice);

	my $som = $ws->GHNSInfo();

	if($som->fault){
		my $string = $som->faultstring;
		chomp $string;
		print "Error: $string\n";
	}else{
		my $server = $som->valueof("//GHNSInfoResponse/Array/server");
		my $version = $som->valueof("//GHNSInfoResponse/Array/version");
		my $provider = $som->valueof("//GHNSInfoResponse/Array/provider");
		my $url = $som->valueof("//GHNSInfoResponse/Array/url");
		print "Provider: $provider\n";
		print "Server: $server (Version $version)\n";
		print "URL: $url\n";
	}
}

sub interactive{
	my $shell = wsclient->new;

	run_webservice(undef, $opt_webservice);

	$shell->cmdloop();
}

sub prompt_str{
	"dxs> ";
}

sub smry_info{
	"Display provider information";
}

sub smry_webservice{
	"Toggle webservice URL";
}

sub run_info{
	information($opt_webservice);
}

sub run_webservice{
	shift(@_);
	$opt_webservice = shift(@_);
	if($opt_webservice){
		print "Webservice is set to: $opt_webservice\n";
	}else{
		print "Syntax: webservice <url>\n";
	}
}

sub run_{
	print "\n";
}

